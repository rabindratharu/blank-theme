<?php
/**
 * The sidebar containing the main widget area.
 *
 * @package Blank-Theme
 */

?>

<aside id="secondary" role="complementary">
	<?php dynamic_sidebar( 'sidebar-1' ); ?>
</aside><!-- #secondary -->
