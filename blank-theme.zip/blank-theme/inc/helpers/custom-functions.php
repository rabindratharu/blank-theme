<?php
/**
 * Contains custom functions used for the theme
 *
 * @package Blank-Theme
 */

// Your custom functions here.
