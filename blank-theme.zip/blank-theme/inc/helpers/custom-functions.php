<?php
/**
 * Define custom functions for the theme.
 *
 * @package Blank_Theme
 */