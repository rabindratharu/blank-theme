<?php

/**
 * Contains custom functions used for the theme
 *
 * @package classic-theme
 */