<?php
/**
 * Title: Shop homepage
 * Slug: classic-theme/page-shop-home
 * Categories: classic_theme_page
 * Keywords: starter
 * Block Types: core/post-content
 * Post Types: page, wp_template
 * Viewport width: 1400
 * Description: A shop homepage pattern.
 *
 * @package Classic-Theme
 */

?>

<!-- wp:pattern {"slug":"classic-theme/banner-intro-image"} /-->
<!-- wp:pattern {"slug":"classic-theme/grid-with-categories"} /-->
<!-- wp:pattern {"slug":"classic-theme/media-instagram-grid"} /-->
